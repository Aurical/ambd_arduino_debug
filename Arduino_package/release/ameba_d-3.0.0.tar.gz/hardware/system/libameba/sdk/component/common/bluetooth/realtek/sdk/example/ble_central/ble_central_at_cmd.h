#ifndef _BLE_CENTRAL_AT_CMD_H_
#define _BLE_CENTRAL_AT_CMD_H_

#ifdef  __cplusplus
extern "C" {
#endif      /* __cplusplus */


#ifdef  __cplusplus
}
#endif      /*  __cplusplus */

#endif

