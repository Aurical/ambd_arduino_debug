#ifndef PLATFORM_STDLIB_CUSTOMER_H
#define PLATFORM_STDLIB_CUSTOMER_H

#include <customer_rtos_service.h>
  
#endif // PLATFORM_STDLIB_CUSTOMER_H
