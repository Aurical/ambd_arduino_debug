
#ifndef _BLE_AUTO_TEST_TC_1000_H_
#define _BLE_AUTO_TEST_TC_1000_H_


#ifdef __cplusplus
extern "C" {
#endif

#if F_CP_TEST_SUPPORT
void tc_1000_hw_init(void);
void tc_1000_start(void);
void tc_1001_start(void);
void tc_1002_start(void);
#endif


#ifdef __cplusplus
}
#endif

#endif

